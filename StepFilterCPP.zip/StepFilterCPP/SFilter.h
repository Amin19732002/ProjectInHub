#ifndef SFILTER_H_INCLUDED
#define SFILTER_H_INCLUDED
class SFilter{
    public:
//**************************************
// max min functions

int max(int num1, int num2)
{
    return (num1 > num2 ) ? num1 : num2;
}


int min(int num1, int num2)
{
    return (num1 > num2 ) ? num2 : num1;
}
//end of max min functions

int Filter(int sig, int FilterPower){
// Percentage of the maximum possible Filter Power
// 0 means no filter power, 100 means maximum filter power
//****************************************
   static int baias=0;
   static int Counter;
   static int Jump=0;
   static int Remain=1;
   static int Delta=0;
   static int SigFilter=0;
   static int sigz1=0;



     Delta=sig-sigz1;
    //Delta must be considered as below, where n is number of past samples
    //Delta=max(SOC-SOCZ1,SOC-SOCZ2,SOC-SOCZ3...,SOC-SOCZn)
    // Jump detection
    if (abs(Delta)>10 && (FilterPower)>0)
    {Counter=0;
    // Jump is the remaining value from earlier Jumps and the new one that is measured as Delta
    Jump=Delta+baias;
    // Remain is the maximum possible distance to  zero or 100.0%
    Remain=max(min(sig,1000-sig),1);
    Remain=min(max(abs(Delta),abs(Jump)),Remain);
    // Filter Effect change the Remain value to make the filter faster or slower
    if (FilterPower <1) FilterPower=1;
    Remain=(FilterPower)*Remain/100;
    if (Remain<1)Remain=1;

    }
    // SOC filter is equal to SOC if there is no jump otherwise baias slow down the  jump
    baias=Jump-(Jump*Counter)/Remain;
    SigFilter=sig-baias;



//Turn off filter
if (Counter > Remain)
   {
     Counter=0;
     Jump=0;

   }
 // Turn on filter
if ( abs(SigFilter-sig)>0 && abs(Delta)>0)
   {
     Counter++;

   }
  // sigz1 is the previous sig  sample
       sigz1=sig;
return SigFilter;

}



};


#endif // SFILTER_H_INCLUDED

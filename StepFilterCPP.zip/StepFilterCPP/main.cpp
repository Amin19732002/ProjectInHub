#include <iostream>
#include "C:\MyWork\CodeBlocks\stepbasefilter\StepFilterCPP\SFilter.h"
#include "C:\MyWork\CodeBlocks\stepbasefilter\Signal.h"
using namespace std;

int main()
{
    int time=0;
    int SOC=0;
    int SOCZ1=0;
    int SOCFilter=0;
     SFilter sf;
//Result Output

FILE *fp;
fp=fopen("c://MyWork/CodeBlocks/stepbasefilter/ResultOutput/output.csv","w");


// time loop
 for (time=0;time<=1100;++time  )
     {
       SOC=Signal(time);
       SOCFilter=sf.Filter(SOC,70);



       fprintf(fp,"Data;%d;%d;\n",1000-SOC,1000-SOCFilter);

     }
fclose(fp);
    return 0;
}
